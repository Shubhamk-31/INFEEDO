const Joi = require('joi');

const taskSchema = Joi.object({
  description: Joi.string().required(),
});

const taskUpdateSchema = Joi.object({
  status: Joi.string().valid('open_task','inprogress_task','completed_task').optional()
});

module.exports = {
  taskSchema,
  taskUpdateSchema
};
