const express = require('express');
const router = express.Router();
const taskController = require('./controllers/taskController');

router.get('/tasks', taskController.getAllTasks);

router.post('/tasks', taskController.createTask);

router.get('/tasks/metrics', taskController.getTasksByStatus);

router.put('/tasks/:id', taskController.updateTask);

module.exports = router;