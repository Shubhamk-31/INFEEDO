const Task = require('../models/Task');
const { taskSchema, taskUpdateSchema } = require('../validation');
const { Op, Sequelize } = require('sequelize');

async function getAllTasks(req, res) {
  try {
    const { query: { limit, offset } } = req
    const tasks = await Task.findAll({
      offset:parseInt(offset, 10) || 0, limit: parseInt(limit, 10) || 0

    });

    res.json(tasks);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Internal server error' });
  }
}

async function createTask(req, res) {
  try {
    const { error } = taskSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }

    const { description } = req.body;
    const task = await Task.create({ description });

    res.json(task);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Internal server error' });
  }
}

async function updateTask(req, res) {
  try {
    const { body: { status }, params: { id } } = req;
    const { error } = taskUpdateSchema.validate({ status });
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }
    const task = await Task.findOne({ where: { id } });
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    await task.update({ status });

    res.json(task);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Internal server error' });
  }
}

async function getTasksByStatus(req, res) {
  try {
    const attributesData = [
      [
        Sequelize.literal('SUM(CASE WHEN status = "open_task" THEN 1 ELSE 0 END)'),
        'open_tasks',
      ],
      [
        Sequelize.literal('SUM(CASE WHEN status = "inprogress_task" THEN 1 ELSE 0 END)'),
        'inprogress_tasks',
      ],
      [
        Sequelize.literal('SUM(CASE WHEN status = "completed_task" THEN 1 ELSE 0 END)'),
        'completed_tasks',
      ]];
    const taskMetricsData = await Task.findAll({
      attributes: attributesData
    });

// Get the current year
const currentYear = new Date().getFullYear();

// Generate an array of month names for all months in the year
const monthNames = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

// Create an array to hold the monthly metrics
const monthlyMetrics = [];

// Loop through each month and fetch the metrics
for (let month = 0; month < 12; month++) {
  const startDate = new Date(currentYear, month, 1);
  const endDate = new Date(currentYear, month + 1, 0);

  const taskMetrics = await Task.findAll({
    attributes: attributesData,
    where: {
      createdAt: {
        [Op.between]: [startDate, endDate],
      },
    },
  });

  // Calculate the month name
  const monthName = monthNames[month];

  // Create an object with the metrics for the current month
  const metrics = {
    date: `${monthName}`,
    open_tasks: taskMetrics[0].dataValues.open_tasks || 0,
    inprogress_tasks: taskMetrics[0].dataValues.inprogress_tasks || 0,
    completed_tasks: taskMetrics[0].dataValues.completed_tasks || 0,
  };

  // Add the metrics to the array
  monthlyMetrics.push(metrics);
}
    
    res.json({ total: taskMetricsData, metrics: monthlyMetrics });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Internal server error' });
  }
}


module.exports = {
  getAllTasks,
  createTask,
  updateTask,
  getTasksByStatus
};
