const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('Task', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
});

// Sync the models with the database schema
sequelize.sync()
  .then(() => {
    console.log('Database and tables synchronized.');
  })
  .catch((error) => {
    console.error('Error synchronizing database:', error);
  });

module.exports = sequelize;
